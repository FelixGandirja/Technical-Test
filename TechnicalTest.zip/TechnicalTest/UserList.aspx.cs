﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace TechnicalTest
{
    public partial class UserList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView();
            }
        }

        private void BindGridView()
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UserManagementDB"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("GetAllUsers", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        gvUsers.DataSource = dt;
                        gvUsers.DataBind();
                    }
                }
                catch (Exception ex)
                {
                    // Handle errors
                    Response.Write("An error occurred: " + ex.Message);
                }
            }
        }

        protected void btnAddNewUser_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEditUser.aspx");
        }

        protected void gvUsers_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditUser")
            {
                string userID = e.CommandArgument.ToString();

                Response.Redirect("AddEditUser.aspx?UserID=" + userID);
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string exportFormat = DropDownList1.SelectedValue;

            switch (exportFormat)
            {
                case "PDF":
                    ExportToPDF();
                    break;
                case "XLS":
                    ExportToExcel();
                    break;
                case "CSV":
                    ExportToCSV();
                    break;
                default:
                    break;
            }
        }

        private void ExportToPDF()
        {
            ReportDocument report = new ReportDocument();
            report.Load(Server.MapPath("~/UserReport.rpt"));
            report.SetDataSource(GetUserData());

            Stream stream = report.ExportToStream(ExportFormatType.PortableDocFormat);
            stream.Seek(0, SeekOrigin.Begin);

            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=UserList.pdf");

            using (MemoryStream memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                Response.BinaryWrite(memoryStream.ToArray());
            }

            Response.End();
        }

        private void ExportToExcel()
        {
            ReportDocument report = new ReportDocument();
            report.Load(Server.MapPath("~/UserReport.rpt"));
            report.SetDataSource(GetUserData());

            Stream stream = report.ExportToStream(ExportFormatType.Excel);
            stream.Seek(0, SeekOrigin.Begin);

            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("content-disposition", "attachment;filename=UserList.xls");

            using (MemoryStream memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                Response.BinaryWrite(memoryStream.ToArray());
            }

            Response.End();
        }

        private void ExportToCSV()
        {
            ReportDocument report = new ReportDocument();
            report.Load(Server.MapPath("~/UserReport.rpt"));
            report.SetDataSource(GetUserData());

            Stream stream = report.ExportToStream(ExportFormatType.CharacterSeparatedValues);
            stream.Seek(0, SeekOrigin.Begin);

            Response.Clear();
            Response.Buffer = true;
            Response.ContentType = "text/csv";
            Response.AddHeader("content-disposition", "attachment;filename=UserList.csv");

            using (MemoryStream memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                Response.BinaryWrite(memoryStream.ToArray());
            }

            Response.End();
        }

        private DataTable GetUserData()
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UserManagementDB"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllUsers", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    return dt;
                }
            }
        }

        protected void gvUsers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlPageSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvUsers.PageSize = int.Parse(ddlPageSize.SelectedValue);
            BindGridView();
        }

        protected void txtPageNumber_TextChanged(object sender, EventArgs e)
        {
            int pageNumber;
            if (int.TryParse(txtPageNumber.Text.Trim(), out pageNumber) && pageNumber > 0 && pageNumber <= gvUsers.PageCount)
            {
                gvUsers.PageIndex = pageNumber - 1;
                BindGridView();
            }
            else
            {
                // Handle invalid page number input
                txtPageNumber.Text = (gvUsers.PageIndex + 1).ToString();
            }
        }
        protected void gvUsers_DataBound(object sender, EventArgs e)
        {
            lblTotalPages.Text = (gvUsers.PageIndex + 1) + " of " + gvUsers.PageCount;
        }

        private void BindGrid()
        {
            DataTable dt = GetUserData();
            gvUsers.DataSource = dt;
            gvUsers.DataBind();
        }

        protected void gvUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvUsers.PageIndex = e.NewPageIndex;
            BindGridView();
        }
        
    }
}