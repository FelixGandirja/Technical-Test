﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace TechnicalTest
{
    public partial class AddEditUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["UserID"] != null)
                {
                    lblTitle.Text = "Edit User";
                    hdnUserID.Value = Request.QueryString["UserID"];
                    LoadUserData();
                }
                else
                {
                    lblTitle.Text = "Add New User";
                }
            }
        }

        private void LoadUserData()
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UserManagementDB"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("GetUserByID", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@UserID", hdnUserID.Value);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtUsername.Text = reader["Username"].ToString();
                                txtFirstName.Text = reader["FirstName"].ToString();
                                txtLastName.Text = reader["LastName"].ToString();
                                chkIsActive.Checked = (bool)reader["IsActive"];
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle errors
                    Response.Write("An error occurred: " + ex.Message);
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) ||
                string.IsNullOrEmpty(txtFirstName.Text) ||
                string.IsNullOrEmpty(txtLastName.Text) ||
                string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                lblError.Text = "Make sure all fields are filled";
                lblError.Visible = true;
                return;
            }


            if(txtPassword.Text != txtConfirmPassword.Text){
                lblError.Text = "passwords do not match";
                lblError.Visible = true;
                return;
            }


            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["UserManagementDB"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    string loginID = Session["LoginID"] as string;
                    if (string.IsNullOrEmpty(hdnUserID.Value))
                    {
                        using (SqlCommand command = new SqlCommand("InsertUser", connection))
                        {
                            command.CommandType = System.Data.CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@Username", txtUsername.Text);
                            command.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                            command.Parameters.AddWithValue("@LastName", txtLastName.Text);
                            command.Parameters.AddWithValue("@IsActive", chkIsActive.Checked);
                            command.Parameters.AddWithValue("@Password", txtPassword.Text);
                            command.Parameters.AddWithValue("@LastModifiedBy", loginID);

                            command.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        using (SqlCommand command = new SqlCommand("UpdateUser", connection))
                        {
                            command.CommandType = System.Data.CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@UserID", hdnUserID.Value);
                            command.Parameters.AddWithValue("@Username", txtUsername.Text);
                            command.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                            command.Parameters.AddWithValue("@LastName", txtLastName.Text);
                            command.Parameters.AddWithValue("@IsActive", chkIsActive.Checked);
                            command.Parameters.AddWithValue("@LastModifiedBy",loginID);

                            command.ExecuteNonQuery();
                        }
                    }

                    Response.Redirect("UserList.aspx");
                }
                catch (Exception ex)
                {
                    // Handle errors
                    Response.Write("An error occurred: " + ex.Message);
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserList.aspx");
        }
        

    }
}